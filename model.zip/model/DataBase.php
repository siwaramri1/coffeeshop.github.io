<?php
class DataBase{
	
	
	private static $connex;
	
	
	private static function init(){
		self::$connex=new PDO("mysql:host=localhost:3306;dbname=nouvelle tableau","root","");
	}
	
	
	private static function getConnex(){
		if (self::$connex==NULL){
		self::init();}
		return (self::$connex);
	}
	
	
	public static function query($req,$class){
		$stm=self::getConnex()->query($req);
		$stm->setFetchMode(PDO::FETCH_CLASS,$class);
		return ($stm->fetchall());
	}
	

	public static function execute($req,$tab){
		$stm=self::getConnex()->prepare($req);
		$r=$stm->execute($tab);
	return ($r);}
	
}