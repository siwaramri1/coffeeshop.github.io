<?php
require_once'DataBase.php';
class Food{
	private $id;
	private $nom;
	private $image;
	private $description;
	private $prix;
public function __construct($t=array()){
		foreach ($t as $k=>$v){
			$this->$k= $v;
		}
	}
public function get($att){
	return $this->$att;}
	
public function set($att,$v){
	return $this->$att=$v;}
	
public static function getAll(){
		$req="SELECT * FROM `food`";
	return (DataBase::query($req,'Food'));
	}
public  function delete (){
		$req="DELETE FROM `food` where id=:id";
		$tab=array("id"=>$this->id);
		$p=DataBase::execute($req,$tab);
		if ($p)
	echo"ok";}
public function save(){
	$req="INSERT INTO `food`(id,nom,image,description,prix)values(NULL,:nom,:image,:description,:prix)";
	$tab=array(
	            'nom'=>$this->nom,
				'image'=>$this->image,
				'description'=>$this->description,
				'prix'=>$this->prix);
	$stm=DataBase::execute($req,$tab);
	if ($stm)
	echo"ok save";}
public function update(){
	$req="UPDATE `food` SET
		      nom=:nom,
			  image=:image,
			  description=:description,
			  prix=:prix where id=:id";
	$tab=array('id'=>$this->id,
	           'nom'=>$this->nom,
				'description'=>$this->description,
				'image'=>$this->image,
				'prix'=>$this->prix);
	$res=DataBase::execute($req,$tab);
	if ($res)
	echo"ok update";}
     
	
	
}