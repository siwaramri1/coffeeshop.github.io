<?php
require_once'IcedCoffeeCrud.php';


//$cafe=IcedCoffeeCrud::getAll();
//var_dump($cafe);
/*$tab=array("id"=>7);
$cafe=new IcedCoffeeCrud($tab);
$r=$cafe->delete();
if ($r) 
	echo"delete ok";
var_dump($cafe);
*/
/*$tab=array(
	            'nom'=>'siwar',
				'image'=>'image.jpg',
				'description'=>'ffffffff',
				'prix'=>500);*/
				/*$cafe=new IcedCoffeeCrud($tab);
$r=$cafe->delete();
if ($r) 
	echo"save ok";*/
	$tab=array('id'=>8
	          );
$cafe=new IcedCoffeeCrud($tab);
$cafe->delete();




				
				




?>