<?php
require_once'food.php';
$food=Food::getAll();
var_dump($food);
?>