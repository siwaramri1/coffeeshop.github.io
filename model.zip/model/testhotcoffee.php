<?php
require_once'HotCoffeeCrud.php';
/*$cafe=HotCoffeeCrud::getAll();
var_dump($cafe);
*/
$tab=array("id"=>8);
$cafe=new HotCoffeeCrud($tab);
$cafe->delete();
?>