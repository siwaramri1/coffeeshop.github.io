<?php
require_once'Model/HotCoffeeCrud.php';
class ControllerHot{
	
public static function getAll(){
$coffee=HotCoffeeCrud::getAll();
require_once'view/listeHot.php';}

public static function delete(){
	if (isset($_GET["id"])){
	$cafe=new HotCoffeeCrud(array("id"=>$_GET["id"]));
$cafe->delete();}
}
public static function save(){
	
    // créer un nouvel objet IcedCoffee et enregistrer les données dans la base de données
    $coffee= new HotCoffeeCrud(array('nom' =>"sIWAR","image"=> "pdf","description" => "qqq","prix"=>"50"));
     $coffee->save();
	 
}


public static function update(){
	$hotcoffee= new HotCoffeeCrud(array('id'=>9,'nom' =>"salim","image"=> "pdf","description" => "qqq","prix"=>"50"));
$hotcoffee->update();}
}
	




?>