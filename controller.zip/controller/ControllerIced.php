<?php
require_once'model/IcedCoffeeCrud.php';
class ControllerIced{
	
public static function getAll(){
$cafes=IcedCoffeeCrud::getAll();
require_once'View/listeIced.php';}

public static function delete(){
	if (isset($_GET["id"])){
	$cafe=new IcedCoffeeCrud(array("id"=>$_GET["id"]));
$cafe->delete();}
}
public static function save(){
	
    // créer un nouvel objet IcedCoffee et enregistrer les données dans la base de données
    $coffee= new IcedCoffeeCrud(array('nom' =>"sIWAR","image"=> "pdf","description" => "qqq","prix"=>"50"));
     $coffee->save();
}


public static function update(){
	$icedcoffee= new IcedCoffeeCrud(array('id'=>14,'nom' =>"salim","image"=> "pdf","description" => "qqq","prix"=>"50"));
$icedCoffee->update();}
}
	




?>