<?php
require_once'Model/food.php';
class ControllerFood{
	
public static function getAll(){
$food=Food::getAll();
require_once'view/listefood.php';}

public static function delete(){
	if (isset($_GET["id"])){
	$food=new Food(array("id"=>$_GET["id"]));
$food->delete();}
}
public static function save(){
	
    // créer un nouvel objet IcedCoffee et enregistrer les données dans la base de données
    $food= new Food(array('nom' =>"sIWAR","image"=> "pdf","description" => "qqq","prix"=>"50"));
     $food->save();
	 
}


public static function update(){
	$food= new Food(array('id'=>6,'nom' =>"salim","image"=> "pdf","description" => "qqq","prix"=>"50"));
$food->update();}
}
	




?>